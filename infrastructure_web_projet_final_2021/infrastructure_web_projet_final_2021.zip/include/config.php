<?php
    /* Information sur hostpapa */
    
    /*$username = "maxime059_administrateur";
    $password = "!^fGq6R${+0^";
    $host = "localhost";
    $database = "maxim059_projetfinal";
    $db = "maxim059_projet1";*/

    /* Information sur Ampps */

    $username = "root";
    $password = "mysql";
    $host = "localhost";
    $database = "projet_final";
    $db = "0335324" 
?>
